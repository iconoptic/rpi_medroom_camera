# uv4l-webrtc-front-end
UV4L Webrtc Front-End Source Code

Original source code of UV4L WebRTC front end. No code changes, only split html, js and css. Code by [https://www.linux-projects.org](https://www.linux-projects.org/)


