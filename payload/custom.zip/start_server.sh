#!/bin/bash

#uv4l --external-driver --device-name=video1 --config-file=/home/simuser/custom/medroom.conf

/usr/bin/uv4l -f -k --sched-fifo --mem-lock --config-file=/home/simuser/custom/medroom.conf --driver=uvc --device-id=046d:082c
