#!/bin/bash

i=1; cat main.js | grep 'style.height' | cut -d\" -f2 | cut -dp -f1 | while read line; do printf %.0f $(echo "$line*(4/3)" | bc -l); echo; done | while read line; do orig="$(cat main.js | grep 'style.width' | head -$i | tail -1)"; repl="$(echo -e "$orig" | sed "s/[0-9]\{3,4\}/$line/g")"; sed "s/$orig/$repl/g" -i main.js; i=$((i+1)); done
